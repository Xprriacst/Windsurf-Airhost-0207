// netlify/functions/fcm-send.js
exports.handler = async (event, context) => {
  return {
    statusCode: 410,
    // Gone - indique que la ressource n'est plus disponible
    body: JSON.stringify({
      error: "Cette fonction a \xE9t\xE9 d\xE9sactiv\xE9e. Les notifications FCM sont d\xE9sormais g\xE9r\xE9es par l'Edge Function Supabase.",
      redirectTo: "https://pnbfsiicxhckptlgtjoj.supabase.co/functions/v1/fcm-proxy"
    })
  };
};
