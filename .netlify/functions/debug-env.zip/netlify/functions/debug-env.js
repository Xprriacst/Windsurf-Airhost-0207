var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/debug-env.ts
var debug_env_exports = {};
__export(debug_env_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(debug_env_exports);
var handler = async (event, context) => {
  try {
    const envVars = {
      SUPABASE_URL: process.env.SUPABASE_URL ? "D\xE9fini" : "Non d\xE9fini",
      SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY ? "D\xE9fini" : "Non d\xE9fini",
      OPENAI_API_KEY: process.env.OPENAI_API_KEY ? "D\xE9fini" : "Non d\xE9fini",
      OPENAI_ORG_ID: process.env.OPENAI_ORG_ID ? "D\xE9fini" : "Non d\xE9fini",
      NODE_VERSION: process.env.NODE_VERSION || "Non d\xE9fini"
      // Ajouter d'autres variables d'environnement si nécessaire
    };
    const requestInfo = {
      httpMethod: event.httpMethod,
      path: event.path,
      headers: event.headers,
      queryStringParameters: event.queryStringParameters,
      body: event.body ? "Pr\xE9sent" : "Non pr\xE9sent"
    };
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Informations de d\xE9bogage",
        environment: process.env.NODE_ENV || "Non d\xE9fini",
        envVars,
        requestInfo,
        functionRuntime: {
          nodeVersion: process.version,
          platform: process.platform,
          arch: process.arch
        }
      }, null, 2)
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message || "Erreur interne du serveur" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
